# Ilangai Makkal Matrimony — Simple Android app

This is Option A: a basic Android app that opens https://ilangaimakkalmatrimony.com/ inside the app.

## Build the APK
1. Install Android Studio on a computer: https://developer.android.com/studio
2. Extract this ZIP.
3. In Android Studio, open the extracted `IlangaiMakkalMatrimonySimpleApp` folder.
4. Wait for Gradle sync and install any requested SDK components.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Transfer the generated APK to your Android phone and install it.

The APK is not included because this environment does not have the Android build toolchain installed. Website features depend on the website itself and an internet connection.
